 $('#btn1').on('click', function(){    

        var studentNumber = $('#uname').val();
        var password = $('#pass').val();

        if(studentNumber == ''|| password == '' ){
            swal({
              title: "Fields Empty!!",
              text: "Please fill the missing field!",
              icon: "warning",
              button: "Ok!",
            })
        }
        else{
            swal({
              title: "You've sucessfully Log in!",
              icon: "success",
              button: "Ok!",
            })
        }
});
const errorElement = document.getElementById('user-img')
form.addEventListener('submit', (e) => {
    
        e.preventDefault()
    }
)